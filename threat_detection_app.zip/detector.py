import re

patterns = {
    "ip": r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b",
    "url": r"https?://[^\s]+",
    "hash": r"\b[a-fA-F0-9]{32,64}\b",
    "keywords": ["malware", "attack", "breach", "trojan", "ransomware"]
}

def detect_threat(text):
    findings = []

    if re.search(patterns["ip"], text):
        findings.append("Suspicious IP detected")

    if re.search(patterns["url"], text):
        findings.append("Suspicious URL detected")

    if re.search(patterns["hash"], text):
        findings.append("File hash detected")

    for word in patterns["keywords"]:
        if word.lower() in text.lower():
            findings.append(f"Keyword threat detected: {word}")

    if findings:
        return True, findings
    else:
        return False, ["No threats found"]

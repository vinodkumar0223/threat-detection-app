from flask import Flask, render_template, request
import os
from detector import detect_threat

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/scan", methods=["POST"])
def scan():
    file = request.files["file"]

    if file:
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(filepath)

        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        is_threat, results = detect_threat(content)

        return render_template("index.html",
                               result=results,
                               threat=is_threat)

    return "No file uploaded"

if __name__ == "__main__":
    app.run(debug=True)
